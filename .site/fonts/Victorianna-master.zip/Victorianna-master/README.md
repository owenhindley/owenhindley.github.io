# Victorianna

![specimen](https://github.com/velvetyne/victorianna/blob/master/specimen.png)

Thin roman & italic font, inspired by english victorian types. Thin roman: 3 titling styles on caps, ligatures on lower cases. Thin italic: many ligatures on lower cases. Originally drawn by Sébastien Hayez, then developed by Jérémy Landes.

Contribute or download it on [Velvetyne Type Foundry](http://velvetyne.fr/fonts/victorianna/).

## License

Victorianna is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at
http://scripts.sil.org/OFL

## Repository Layout

This font repository follows the Sample font repository based on the Unified Font Repository v2.0,
a standard way to organize font project source files. Learn more at :
- https://github.com/djrrb/Sample-Font-Repository
- https://github.com/raphaelbastide/Unified-Font-Repository
