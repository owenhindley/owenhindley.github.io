Copyright (c) 2014-2017, Sébastien Hayez <hayezsebastien@hotmail.com> & Jérémy Landes <jeremy@studiotriple.fr>
