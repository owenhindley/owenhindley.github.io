FONTLOG for Sample Font
-------------------

This file provides detailed information on the Victorianna font software.


Basic Font Information
--------------------------

Victorianna is an awesome typeface inspired by english victorian types. Read more in the [docs](/documentation).


Information for Contributors
------------------------------

See the project website for the current trunk and the various branches:

https://github.com/velvetyne/victorianna/


ChangeLog
----------

When you make modifications, be sure to add a description of your changes,
following the format of the other entries, to the start of this section.

7 April 2014 (Jérémy Landes) Victorianna V1
- Initial push of font "Victorianna"


Acknowledgements
-------------------------

When you make modifications, be sure to add your name (N), email (E),
web-address (W) and description (D). This list is sorted by last name in
alphabetical order.

N: Sébastien Hayez
E: hayezsebastien@hotmail.com
D: Typeface designer

N: Jérémy Landes
E: jeremy@studiotriple.fr
W: http://www.studiotriple.fr
D: Typeface designer
